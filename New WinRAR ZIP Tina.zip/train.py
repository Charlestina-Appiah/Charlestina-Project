import os
os.environ['PATH'] = f"{os.environ['PATH']}:/root/.local/bin"
os.environ['PATH'] = f"{os.environ['PATH']}:/opt/conda/lib/python3.6/site-packages"
# Imports here

import torch
import argparse
from torch import nn
import torchvision
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms,models
from torchvision.datasets import ImageFolder
from torch.utils import data
from PIL import Image
import numpy as np
import os, random
import json
import signal
from torch.utils.data import DataLoader
from contextlib import contextmanager
import requests
from transform import train_loader, valid_loader, test_loader, training_dataset


# Load pre-trained VGG model
def train_model(model_type='vgg16', epochs=5, learning_rate=0.001, checkpoint_path='checkpoint.pth'):
    # Load data
    
    # Load pre-trained model
    if model_type == 'vgg16':
        model = models.vgg16(pretrained=True)
    elif model_type == 'vgg19':
        model = models.vgg19(pretrained=True)
    else:
        raise ValueError("Invalid model type. Choose 'vgg16' or 'vgg19'.")

    # Freeze the parameters of the pre-trained model
    for param in model.parameters():
        param.requires_grad = False

    # Modify the classifier of VGG
    classifier = nn.Sequential(
        nn.Linear(25088, 2048),
        nn.ReLU(inplace=True),
        nn.Dropout(0.2),
        nn.Linear(2048, 102),
        nn.LogSoftmax(dim=1)
    )
    
    model.classifier = classifier
    
    # Define loss function and optimizer
    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.classifier.parameters(), lr=learning_rate)
    
    # Move the model to the device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    # Train the model
    steps = 0
    print_every = 15

    for epoch in range(epochs):
        model.train()
        running_train_loss = 0.0

        for images, labels in train_loader:
            # Move images and model to device
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_train_loss += loss.item()

        print(f"Epoch {epoch + 1}/{epochs}.. "f"Train loss: {running_train_loss / len(train_loader):.3f}")
        
        # Save checkpoint after each epoch
        checkpoint = {
    'state_dict': model.state_dict(),
    'class_to_idx': training_dataset.class_to_idx,
    'classifier': model.classifier,
    'optimizer_state_dict': optimizer.state_dict(),
    'epochs': epochs
}

        torch.save(checkpoint, 'model_checkpoint.pth')
       

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Train a model with VGG16 or VGG19 architecture.')
    parser.add_argument('--model_type', type=str, default='vgg16', choices=['vgg16', 'vgg19'],
                        help='Choose the architecture of the model (vgg16 or vgg19). Default is vgg16.')
    parser.add_argument('--epochs', type=int, default=5, help='Number of epochs for training. Default is 5.')
    parser.add_argument('--learning_rate', type=float, default=0.001, help='Learning rate for training. Default is 0.001.')
    parser.add_argument('--checkpoint_path', type=str, default='checkpoint.pth', help='Path to save the model checkpoint. Default is checkpoint.pth.')
    args = parser.parse_args()

    train_model(model_type=args.model_type, epochs=args.epochs, learning_rate=args.learning_rate, checkpoint_path=args.checkpoint_path)
