
import argparse
import torch
import torchvision
from torch import nn, optim
from torchvision import transforms
import torchvision.models as models
from torchvision.datasets import ImageFolder
from torch.utils import data
from PIL import Image
import numpy as np
import os, random
import matplotlib
import matplotlib.pyplot as plt
import json
parser = argparse.ArgumentParser(description = 'Parser for train.py')
parser.add_argument('--arch', action="store", default="vgg16")
args = parser.parse_args()
struct = args.arch
import json

with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)

def load_checkpoint(filepath):
    
    # Create a model with the same architecture as during training
    model = models.vgg16(pretrained=True)  # Use the same architecture as in your training script
    checkpoint = torch.load('model_checkpoint.pth')

# Rebuild the model
    model = models.vgg16(pretrained=True)
    model.classifier = checkpoint['classifier']
    model.load_state_dict(checkpoint['state_dict'])

# Attach class to index mapping to the model
    model.class_to_idx = checkpoint['class_to_idx']

    return model

def process_image(image):#this function's code was taken from:https://github.com/PaMcD/Create-Your-Own-Image-Classifier/blob/main/Image%20Classifier%20Project.ipynb
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    
    # TODO: Process a PIL image for use in a PyTorch model
    pil_image = Image.open(image_path)
    

    # TODO: Process a PIL image for use in a PyTorch model
    
    # reize
    pil_image.resize((256,256))
    
    # centre crop
    width, height = pil_image.size   # Get dimensions
    new_width, new_height = 224, 224
    
    left = round((width - new_width)/2)
    top = round((height - new_height)/2)
    x_right = round(width - new_width) - left
    x_bottom = round(height - new_height) - top
    right = width - x_right
    bottom = height - x_bottom

    # Crop the center of the image
    pil_image = pil_image.crop((left, top, right, bottom))
    
    # convert colour channel from 0-255, to 0-1
    np_image = np.array(pil_image)/255
    
    # normalize for model
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    np_image = (np_image - mean)/std
    
    # tranpose color channge to 1st dim
    np_image = np_image.transpose((2 , 0, 1))
    
    # convert to Float Tensor
    tensor = torch.from_numpy(np_image)
    tensor = tensor.type(torch.FloatTensor)
   
    # return tensor
    return tensor
def imshow(image, ax=None, title=None):
    """Imshow for Tensor."""
    if ax is None:
        fig, ax = plt.subplots()
    
    image = image.numpy().transpose((1, 2, 0))
    
    # Undo preprocessing
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    image = std * image + mean
    
    # Image needs to be clipped between 0 and 1 or it looks like noise when displayed
    image = np.clip(image, 0, 1)
    
    ax.imshow(image)
    
    return ax
def predict(image_path, model, topk=5):
    
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    
    # TODO: Implement the code to predict the class from an image file
    image = process_image(image_path)
    image = image.unsqueeze(0)

    # move to device
    image = image.to(device)
    model.eval()
    with torch.no_grad():
        ps = torch.exp(model(image))
        
    idx_to_flower = {v:cat_to_name[k] for k, v in model.class_to_idx.items()}    
    
    top_ps, top_classes = ps.topk(topk, dim=1)
    predicted_flowers = [idx_to_flower[i] for i in top_classes.tolist()[0]]

    return top_ps.tolist()[0], predicted_flowers
# predicting Image


# Load the model using your load_checkpoint function
checkpoint_path = 'checkpoint.pth'
model = load_checkpoint(checkpoint_path)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# Now you can use the loaded model for prediction
image_path = "flowers/test/10/image_07090.jpg"
probs, classes = predict(image_path, model)
print(probs)
print(classes)