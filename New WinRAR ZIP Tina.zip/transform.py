data_dir = 'flowers'

import torch
from torch import nn
import torchvision
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms,models
from torchvision.datasets import ImageFolder
from torch.utils import data
from PIL import Image
import numpy as np
import os, random
import json
import signal
from torch.utils.data import DataLoader
from contextlib import contextmanager
import requests

train_dir = data_dir + '/train'
valid_dir = data_dir + '/valid'
test_dir = data_dir + '/test'
mean_ = [0.485, 0.456, 0.406]
std_ = [0.229, 0.224, 0.225]

# Define transforms for the training set
data_transforms = transforms.Compose([
    transforms.RandomRotation(degrees=45),
    transforms.RandomHorizontalFlip(),
    transforms.RandomResizedCrop(size=224),
    transforms.ToTensor(),
    transforms.Normalize(mean=mean_, std=std_)
])

# Define transforms for both the validation and testing sets
test_transform = transforms.Compose([
    transforms.Resize(255),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=mean_, std=std_)
]) 

# TODO: Load the datasets with ImageFolder
from torchvision.datasets import ImageFolder

# Create datasets
training_dataset = ImageFolder(root=train_dir, transform=data_transforms)
validation_dataset = ImageFolder(root=valid_dir, transform=data_transforms)
testing_dataset = ImageFolder(root=test_dir, transform=data_transforms)

# Define batch size for the data loaders
batch_size = 32  # You can adjust this value based on your requirements

# Create data loaders
train_loader = DataLoader(training_dataset, batch_size=34, shuffle=True)
valid_loader = DataLoader(validation_dataset, batch_size=34, shuffle=False)
test_loader = DataLoader(testing_dataset, batch_size=batch_size, shuffle=False)